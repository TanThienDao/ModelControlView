import java.awt.Point;
import java.util.Stack;
import java.util.Vector;

public class Professor2 implements Runnable{
    @Override
    public void run() {
        // TODO Auto-generated method stub
        Stack<Point> points = Repository.getInstance().getPoints();
        Stack<Line> lines = Repository.getInstance().getLines();
        boolean runloop=true;
        Vector<Integer> removeIndex= new Vector<Integer>();
        while (runloop)
        {
            System.out.println("Data in points stack");
            for(int i=0;i< points.size();i++)
            {
                System.out.println(points.get(i).getX() +","+ points.get(i).getY());
            }
            System.out.println("Data in Lines stack");
            for(int i=0;i<lines.size();i++)
            {
                System.out.println("line "+i+":");
                for(int j=0;j<4;j++)
                {
                    System.out.print(lines.get(i).getLine()[j]+"    ");
                }
                System.out.println("");

            }
            int count=0;

            for(int i=0;i<lines.size()-1;i++)
            {
                if(lines.peek().getLine()[2]==lines.get(i).getLine()[0]&&
                        lines.peek().getLine()[3]== lines.get(i).getLine()[1])
                {
                    count ++;
                    removeIndex.add(i);

                }
                else if(lines.peek().getLine()[2]==lines.get(i).getLine()[2]&&
                        lines.peek().getLine()[3]== lines.get(i).getLine()[3])
                {
                    count ++;
                    removeIndex.add(i);

                }
                else
                {
                    System.out.println("count  "+count);
                }
                if(count >=4)
                {
                    System.out.println("Remove a line ");
                    for(int r=0;r<removeIndex.size();r++)
                    {
                        //lines.remove(r);

                    }
                    removeIndex.clear();
                    System.out.println("Remove a point ");
                    for(int z=0;z<points.size();z++)
                    {
                        if(lines.peek().getLine()[2]==points.get(z).getX()&&
                                lines.peek().getLine()[3]== points.get(z).getY())
                        {
                            points.remove(z);
                        }
                    }
                    for(int y = 0; y < lines.size();y++) {
                        if(lines.peek().getLine()[2]==lines.get(y).getLine()[2]&&
                                lines.peek().getLine()[3]== lines.get(y).getLine()[3]) {
                            lines.remove(y);
                        }

                    }
                    for(int y = 0; y < lines.size();y++) {
                        if(lines.peek().getLine()[2]==lines.get(y).getLine()[0]&&
                                lines.peek().getLine()[3]== lines.get(y).getLine()[1]) {
                            lines.remove(y);
                        }

                    }
                    count=0;
                }
            }





        }




        try {
            Thread.sleep(1000);
        }catch(Exception e) {

        }

    }

}

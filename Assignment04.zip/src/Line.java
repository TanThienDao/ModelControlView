
public class Line {

}
